document.addEventListener('DOMContentLoaded', function() {
    const fileButton = document.getElementById('fileButton');
    const fileMenu = document.getElementById('fileMenu');
    const importButton = document.getElementById('importButton');
    const exportButton = document.getElementById('exportButton');
    const saveButton = document.getElementById('saveButton');
    const canvas = document.getElementById('photoCanvas');
    const ctx = canvas.getContext('2d');
    const colorPicker = document.getElementById('colorPicker');
    const sizeSlider = document.getElementById('sizeSlider');
    const eraserButton = document.getElementById('eraserButton');
    const squareButton = document.getElementById('squareButton');
    const circleButton = document.getElementById('circleButton');
    const neonButton = document.getElementById('neonButton');
    const textButton = document.getElementById('textButton');
    const fillButton = document.getElementById('fillButton');
    const layerButton = document.getElementById('layerButton');
    const layerMenu = document.getElementById('layerMenu');
    const addLayerButton = document.getElementById('addLayerButton');
    const removeLayerButton = document.getElementById('removeLayerButton');
    const layerList = document.getElementById('layerList');
    const miscButton = document.getElementById('miscButton');
    const miscMenu = document.getElementById('miscMenu');
    const clearButton = document.getElementById('clearButton');
    const resizeButton = document.getElementById('resizeButton');
    const loadStickerButton = document.getElementById('loadStickerButton');

    let drawing = false;
    let currentColor = colorPicker.value;
    let currentSize = sizeSlider.value;
    let currentShape = 'circle';
    let neonMode = false;
    let textMode = false;
    let fillMode = false;
    let layers = [ctx];
    let currentLayerIndex = 0;
    let removeMode = false;
    let lastX = 0;
    let lastY = 0;
    let stickerImage = null;
    let stickerX = 0;
    let stickerY = 0;
    let stickerWidth = 0;
    let stickerHeight = 0;
    let isStickerMoving = false;

    // Функция для открытия/закрытия меню
    fileButton.addEventListener('click', function() {
        fileMenu.style.display = fileMenu.style.display === 'block' ? 'none' : 'block';
    });

    layerButton.addEventListener('click', function() {
        layerMenu.style.display = layerMenu.style.display === 'block' ? 'none' : 'block';
    });

    miscButton.addEventListener('click', function() {
        miscMenu.style.display = miscMenu.style.display === 'block' ? 'none' : 'block';
    });

    // Функция для импорта фото
    importButton.addEventListener('click', function() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = function(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = new Image();
                img.src = e.target.result;
                img.onload = function() {
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0);
                };
            };
            reader.readAsDataURL(file);
        };
        input.click();
    });

    // Функция для экспорта фото
    exportButton.addEventListener('click', function() {
        const link = document.createElement('a');
        link.download = 'photo.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
    });

    // Функция для сохранения фото (в будущем можно добавить сохранение на сервер)
    saveButton.addEventListener('click', function() {
        alert('Photo saved!');
        // Здесь можно добавить логику для сохранения фото на сервер
    });

    // Изменение цвета
    colorPicker.addEventListener('change', function() {
        currentColor = colorPicker.value;
    });

    // Изменение размера карандаша
    sizeSlider.addEventListener('input', function() {
        currentSize = sizeSlider.value;
    });

    // Ластик
    eraserButton.addEventListener('click', function() {
        currentColor = '#ffffff'; // Белый цвет для ластика
    });

    // Квадрат
    squareButton.addEventListener('click', function() {
        currentShape = 'square';
    });

    // Круг
    circleButton.addEventListener('click', function() {
        currentShape = 'circle';
    });

    // Неон
    neonButton.addEventListener('click', function() {
        neonMode = !neonMode;
        neonButton.textContent = neonMode ? 'Neon ON' : 'Neon OFF';
        if (neonMode) {
            ctx.shadowColor = currentColor;
            ctx.shadowBlur = 10;
        } else {
            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
        }
    });

    // Текст
    textButton.addEventListener('click', function() {
        textMode = !textMode;
    });

    // Заливка
    fillButton.addEventListener('click', function() {
        fillMode = !fillMode;
        fillButton.textContent = fillMode ? 'Fill ON' : 'Fill OFF';
    });

    // Слои
    addLayerButton.addEventListener('click', function() {
        const newCanvas = document.createElement('canvas');
        newCanvas.width = canvas.width;
        newCanvas.height = canvas.height;
        layers.push(newCanvas.getContext('2d'));
        currentLayerIndex = layers.length - 1;
        updateLayerList();
    });

    removeLayerButton.addEventListener('click', function() {
        removeMode = !removeMode;
        removeLayerButton.textContent = removeMode ? 'Remove Layer ON' : 'Remove Layer OFF';
    });

    layerList.addEventListener('click', function(event) {
        const layerIndex = Array.from(layerList.children).indexOf(event.target);
        if (removeMode) {
            const confirmDelete = confirm(`Are you sure you want to delete layer ${layerIndex + 1}?`);
            if (confirmDelete) {
                layers.splice(layerIndex, 1);
                currentLayerIndex = Math.max(0, currentLayerIndex - 1);
                updateLayerList();
            }
        } else {
            currentLayerIndex = layerIndex;
            updateLayerList();
        }
    });

    function updateLayerList() {
        layerList.innerHTML = '';
        layers.forEach((layer, index) => {
            const layerItem = document.createElement('div');
            layerItem.textContent = `Layer ${index + 1}`;
            if (index === currentLayerIndex) {
                layerItem.classList.add('active');
            }
            layerList.appendChild(layerItem);
        });
    }

    // Очистка холста
    clearButton.addEventListener('click', function() {
        const confirmClear = confirm('Are you sure you want to clear the canvas?');
        if (confirmClear) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
    });

    // Изменение размера холста
    resizeButton.addEventListener('click', function() {
        const width = prompt('Enter new width:');
        const height = prompt('Enter new height:');
        if (width && height) {
            canvas.width = parseInt(width);
            canvas.height = parseInt(height);
        }
    });

    // Загрузка стикера
    loadStickerButton.addEventListener('click', function() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = function(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = new Image();
                img.src = e.target.result;
                img.onload = function() {
                    stickerImage = img;
                    stickerX = 0;
                    stickerY = 0;
                    const width = prompt('Enter sticker width:');
                    const height = prompt('Enter sticker height:');
                    if (width && height) {
                        stickerWidth = parseInt(width);
                        stickerHeight = parseInt(height);
                        isStickerMoving = true;
                        document.addEventListener('keydown', moveSticker);
                        alert('Use arrow keys to move the sticker. Press Enter to confirm the position.');
                    }
                };
            };
            reader.readAsDataURL(file);
        };
        input.click();
    });

    function moveSticker(event) {
        if (isStickerMoving) {
            switch (event.key) {
                case 'ArrowUp':
                    stickerY -= 10;
                    break;
                case 'ArrowDown':
                    stickerY += 10;
                    break;
                case 'ArrowLeft':
                    stickerX -= 10;
                    break;
                case 'ArrowRight':
                    stickerX += 10;
                    break;
                case 'Enter':
                    isStickerMoving = false;
                    document.removeEventListener('keydown', moveSticker);
                    ctx.drawImage(stickerImage, stickerX, stickerY, stickerWidth, stickerHeight);
                    return;
            }
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(stickerImage, stickerX, stickerY, stickerWidth, stickerHeight);
        }
    }

    // Рисование на canvas
    canvas.addEventListener('mousedown', function(event) {
        drawing = true;
        lastX = event.clientX - canvas.getBoundingClientRect().left;
        lastY = event.clientY - canvas.getBoundingClientRect().top;

        if (fillMode) {
            const currentCtx = layers[currentLayerIndex];
            const imageData = currentCtx.getImageData(0, 0, canvas.width, canvas.height);
            const targetColor = ctx.getImageData(lastX, lastY, 1, 1).data;
            floodFill(imageData, lastX, lastY, targetColor, currentColor);
            currentCtx.putImageData(imageData, 0, 0);
        }
    });

    canvas.addEventListener('mousemove', function(event) {
        if (drawing) {
            const x = event.clientX - canvas.getBoundingClientRect().left;
            const y = event.clientY - canvas.getBoundingClientRect().top;
            draw(lastX, lastY, x, y);
            lastX = x;
            lastY = y;
        }
    });

    canvas.addEventListener('mouseup', function() {
        drawing = false;
    });

    canvas.addEventListener('mouseout', function() {
        drawing = false;
    });

    function draw(startX, startY, endX, endY) {
        const currentCtx = layers[currentLayerIndex];

        currentCtx.beginPath();
        currentCtx.moveTo(startX, startY);
        currentCtx.quadraticCurveTo(startX, startY, endX, endY);
        currentCtx.lineWidth = currentSize;
        currentCtx.lineCap = 'round';
        currentCtx.strokeStyle = currentColor;
        currentCtx.stroke();
        currentCtx.closePath();

        if (neonMode) {
            currentCtx.shadowColor = currentColor;
            currentCtx.shadowBlur = 10;
        } else {
            currentCtx.shadowColor = 'transparent';
            currentCtx.shadowBlur = 0;
        }

        if (textMode) {
            const text = prompt('Enter text:');
            if (text) {
                currentCtx.font = `${currentSize * 2}px Arial`;
                currentCtx.fillText(text, endX, endY);
            }
            textMode = false;
        }
    }

    function floodFill(imageData, x, y, targetColor, fillColor) {
        const width = imageData.width;
        const height = imageData.height;
        const data = imageData.data;
        const stack = [];
        const visited = new Set();

        stack.push([x, y]);

        while (stack.length > 0) {
            const [cx, cy] = stack.pop();
            const index = (cy * width + cx) * 4;

            if (visited.has(index)) continue;
            visited.add(index);

            const r = data[index];
            const g = data[index + 1];
            const b = data[index + 2];
            const a = data[index + 3];

            if (r === targetColor[0] && g === targetColor[1] && b === targetColor[2] && a === targetColor[3]) {
                data[index] = fillColor[0];
                data[index + 1] = fillColor[1];
                data[index + 2] = fillColor[2];
                data[index + 3] = fillColor[3];

                if (cx > 0) stack.push([cx - 1, cy]);
                if (cx < width - 1) stack.push([cx + 1, cy]);
                if (cy > 0) stack.push([cx, cy - 1]);
                if (cy < height - 1) stack.push([cx, cy + 1]);
            }
        }
    }
});